/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.entities;

import java.util.Objects;

/**
 *
 * @author i41278
 */
public class ServiceResponse {
    private String serviceName;
    private long instanceId;
    private String ip;
    private String version;
    private int ttl;

    public ServiceResponse() {
    }

    public ServiceResponse(String serviceName, long instanceId, String ip, String version, int ttl) {
        this.serviceName = serviceName;
        this.instanceId = instanceId;
        this.ip = ip;
        this.version = version;
        this.ttl = ttl;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public long getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(long instanceId) {
        this.instanceId = instanceId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getTtl() {
        return ttl;
    }

    public void setTtl(int ttl) {
        this.ttl = ttl;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.serviceName);
        hash = 97 * hash + Objects.hashCode(this.instanceId);
        hash = 97 * hash + Objects.hashCode(this.ip);
        hash = 97 * hash + Objects.hashCode(this.version);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ServiceResponse other = (ServiceResponse) obj;
        if (!Objects.equals(this.serviceName, other.serviceName)) {
            return false;
        }
        if (!Objects.equals(this.instanceId, other.instanceId)) {
            return false;
        }
        if (!Objects.equals(this.ip, other.ip)) {
            return false;
        }
        if (!Objects.equals(this.version, other.version)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ServiceResponse{" + "serviceName=" + serviceName + ", instanceId=" + instanceId + ", ip=" + ip + ", version=" + version + ", ttl=" + ttl + '}';
    }
    
    
}
