/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.serverImpl;

import com.edf.microservices.entities.Message;
import com.edf.microservices.entities.RegisterInfo;
import com.edf.microservices.entities.ServiceRequest;
import com.edf.microservices.entities.ServiceResponse;
import com.edf.microservices.sr.ServiceRegistry;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author i41278
 */
public class ServiceProtocol implements Runnable {

    private final Socket client;
    private DataInputStream in;
    private DataOutputStream out;
    private ServiceRegistry sr;

    public ServiceProtocol(Socket client) {
        this.client = client;
        this.sr = new ServiceRegistry();
    }

    @Override
    public void run() {
        try {
            Message req = readRequest();
            writeResponse(req);
            this.client.close();
        } catch (IOException ex) {
            Logger.getLogger(ServiceProtocol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private Message readRequest() {
        Message req = new Message();
        try {
            in = new DataInputStream(new BufferedInputStream(client.getInputStream()));
            req.setCommand(in.readByte());
            req.setSize(in.readInt());
            req.setChecksum(in.readLong());
            req.setMsgType(in.readByte());
            req.setBody(in.readNBytes(req.getSize()));
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(ServiceProtocol.class.getName()).log(Level.SEVERE, null, ex);
        }
        return req;
    }

    private void writeResponse(Message req) {
        try {
            Message resp = new Message();
            resp.setCommand(Message.RESPONSE);
            resp.setMsgType(Message.JSON);
            switch (req.getCommand()) {
                case Message.REGISTER: {
                    RegisterInfo service 
                            = MessageJson.fromJson(new String(req.getBody()), RegisterInfo.class);
                    sr.register(service);
                    break;
                }
                case Message.UNREGISTER: {
                    sr.unregister(ByteBuffer.wrap(req.getBody()).getLong());
                    break;
                }
                case Message.FIND_SERVICE: {
                    ServiceRequest serviceReq
                            = MessageJson.fromJson(new String(req.getBody()), ServiceRequest.class);
                    ServiceResponse serviceResp = sr.findService(serviceReq);
                    resp.setBody(MessageJson.toJson(serviceResp).getBytes());
                    resp.setSize(resp.getSize());
                    resp.setChecksum(resp.getChecksum());
                    break;
                }
                case Message.FIND_ALL_SERVICES: {
                    List<RegisterInfo> list = sr.findServices();
                    resp.setBody(MessageJson.toJson(list).getBytes());
                    resp.setSize(resp.getSize());
                    resp.setChecksum(resp.getChecksum());
                    break;
                }
                default: {
                    throw new RuntimeException("Invalid client message method index");
                }
            }
            out = new DataOutputStream(new BufferedOutputStream(client.getOutputStream()));
            out.writeByte(resp.getCommand());
            out.writeInt(resp.getSize());
            out.writeLong(resp.getChecksum());
            out.writeByte(resp.getMsgType());
            out.write(resp.getBody());
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(ServiceProtocol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
