/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.serverImpl;

import com.edf.microservices.server.RegisterServer;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author i41278
 */
public class RegisterServerTCP implements RegisterServer{
    
    private ServerSocket serverSocket;

    @Override
    public void startServerConnection(int portNumber) {
        try {
            serverSocket = new ServerSocket(portNumber);
            ThreadPoolExecutor threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(8);
            while (true) {
                try {
                    Socket listener = serverSocket.accept();
                    threadPool.execute(new ServiceProtocol(listener));
                } catch (IOException ex) {
                    ex.printStackTrace();
                    threadPool.shutdown();
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(RegisterServerTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void stopServerConnection() {
        try {
            serverSocket.close();
        } catch (IOException ex) {
            Logger.getLogger(RegisterServerTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
