/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.database;

import com.edf.microservices.entities.RegisterInfo;
import java.util.List;

/**
 *
 * @author i41278
 */
public interface ServiceDB {
    public void startDBConnection();
    public void stopDBConnection();
    
    public void initRegisterDB();
    public void registerToDB(RegisterInfo service);
    public void unregisterToDB(long id);
    public List<RegisterInfo> findAllServices();
    public RegisterInfo findServiceById(long id);
    public RegisterInfo findServiceMinLoad(String name, String version);
    
}
