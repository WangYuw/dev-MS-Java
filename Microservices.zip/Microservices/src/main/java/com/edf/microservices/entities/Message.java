/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.entities;

import java.util.Arrays;
import java.util.zip.CRC32;

/**
 *
 * @author i41278
 */
public class Message {
    
    public static final byte RESPONSE = 0;
    public static final byte REGISTER = 1;
    public static final byte UNREGISTER = 2;
    public static final byte FIND_SERVICE = 3;
    public static final byte UPDATE_SERVICE_QUALITY = 4;
    public static final byte FIND_ALL_SERVICES = 5;
    
    public static final byte JSON = 1;
    
    private byte command;
    private int size; //body.length
    private long checksum; //CRC32
    private byte msgType;
    private byte[] body;

    public Message() {
    }

    public Message(byte command, byte msgType, byte[] body) {
        this.command = command;
        this.size = body.length;
        CRC32 crc32 = new CRC32();
        crc32.update(body);
        this.checksum = crc32.getValue();
        this.msgType = msgType;
        this.body = body;
    }

    public byte getCommand() {
        return command;
    }

    public void setCommand(byte command) {
        this.command = command;
    }

    public int getSize() {
        return this.body.length;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public long getChecksum() {
        CRC32 crc32 = new CRC32();
        crc32.update(this.body);
        return crc32.getValue();
    }

    public void setChecksum(long checksum) {
        this.checksum = checksum;
    }

    public byte getMsgType() {
        return msgType;
    }

    public void setMsgType(byte msgType) {
        this.msgType = msgType;
    }

    public byte[] getBody() {
        return body;
    }

    public void setBody(byte[] body) {
        this.body = body;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.command;
        hash = 97 * hash + this.size;
        hash = 97 * hash + (int) (this.checksum ^ (this.checksum >>> 32));
        hash = 97 * hash + this.msgType;
        hash = 97 * hash + Arrays.hashCode(this.body);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Message other = (Message) obj;
        if (this.command != other.command) {
            return false;
        }
        if (this.size != other.size) {
            return false;
        }
        if (this.checksum != other.checksum) {
            return false;
        }
        if (this.msgType != other.msgType) {
            return false;
        }
        if (!Arrays.equals(this.body, other.body)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Message{" + "command=" + command + ", size=" + size + ", checksum=" + checksum + ", msgType=" + msgType + ", body=" + body + '}';
    }

    
    
}
