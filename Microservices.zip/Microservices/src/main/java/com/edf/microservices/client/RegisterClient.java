/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.client;

/**
 *
 * @author i41278
 */
public interface RegisterClient {
    
}
