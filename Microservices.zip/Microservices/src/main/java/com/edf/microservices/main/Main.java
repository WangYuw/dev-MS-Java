/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.main;

import com.edf.microservices.config.Config;
import com.edf.microservices.databaseImpl.ServiceDBPostgresql;
import com.edf.microservices.serverImpl.RegisterServerTCP;
import com.edf.microservices.sr.ServiceRegistry;

/**
 *
 * @author i41278
 */
public class Main {
    public static void main(String[] args) {
        
        ServiceRegistry reg = new ServiceRegistry(new RegisterServerTCP(), new ServiceDBPostgresql());
        reg.getServerConnection(Config.DEFAULT_PORT);
    }
}
