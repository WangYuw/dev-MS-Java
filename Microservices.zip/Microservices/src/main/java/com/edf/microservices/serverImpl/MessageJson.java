/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.serverImpl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

/**
 *
 * @author i41278
 */
public class MessageJson {

    private static final String DATA_FORMAT = "yyyy-MM-dd HH:mm:ss";
    
    public static <T> T fromJson(String json, Class<T> classOf) {
        try {
            Gson gson = new GsonBuilder().setDateFormat(DATA_FORMAT).create();
            return gson.fromJson(json, classOf);
        } catch (JsonSyntaxException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static String toJson(Object object) {
        Gson gson = new GsonBuilder().setDateFormat(DATA_FORMAT).create();
        return gson.toJson(object);
    }
}
