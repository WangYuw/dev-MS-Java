/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  i41278
 * Created: 18 juin 2019
 */

DROP TABLE IF EXISTS registry;
CREATE TABLE registry (
    type_name   VARCHAR(255),
    instance_id SERIAL PRIMARY KEY,
    ip          VARCHAR(255) NOT NULL UNIQUE,
    version     VARCHAR(255),
    load        FLOAT
);