/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.entities;

import java.util.Objects;

/**
 *
 * @author i41278
 */
public class ServiceQualityResponse {
    private String serviceName;
    private String instanceId;
    private String ip;
    private ServiceQuality quality;

    public ServiceQualityResponse() {
    }

    public ServiceQualityResponse(String serviceName, String instanceId, String ip, ServiceQuality quality) {
        this.serviceName = serviceName;
        this.instanceId = instanceId;
        this.ip = ip;
        this.quality = quality;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public ServiceQuality getQuality() {
        return quality;
    }

    public void setQuality(ServiceQuality quality) {
        this.quality = quality;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.serviceName);
        hash = 67 * hash + Objects.hashCode(this.instanceId);
        hash = 67 * hash + Objects.hashCode(this.ip);
        hash = 67 * hash + Objects.hashCode(this.quality);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ServiceQualityResponse other = (ServiceQualityResponse) obj;
        if (!Objects.equals(this.serviceName, other.serviceName)) {
            return false;
        }
        if (!Objects.equals(this.instanceId, other.instanceId)) {
            return false;
        }
        if (!Objects.equals(this.ip, other.ip)) {
            return false;
        }
        if (!Objects.equals(this.quality, other.quality)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ServiceQualityResponse{" + "serviceName=" + serviceName + ", instanceId=" + instanceId + ", ip=" + ip + ", quality=" + quality + '}';
    }
    
    
}
