/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.entities;

import java.util.Objects;

/**
 *
 * @author i41278
 */
public class RegisterInfo {
    private String serviceName;
    private long instanceId;
    private String ip;
    private String version;
    private ServiceQuality quality;

    public RegisterInfo() {
    }
    
    public RegisterInfo(String serviceName, long instanceId, String ip, String version, ServiceQuality quality) {
        this.serviceName = serviceName;
        this.instanceId = instanceId;
        this.ip = ip;
        this.version = version;
        this.quality = quality;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public long getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(long instanceId) {
        this.instanceId = instanceId;
    }

    public String getIP() {
        return ip;
    }

    public void setIP(String ip) {
        this.ip = ip;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public ServiceQuality getQuality() {
        return quality;
    }

    public void setQuality(ServiceQuality quality) {
        this.quality = quality;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.serviceName);
        hash = 67 * hash + (int) (this.instanceId ^ (this.instanceId >>> 32));
        hash = 67 * hash + Objects.hashCode(this.ip);
        hash = 67 * hash + Objects.hashCode(this.version);
        hash = 67 * hash + Objects.hashCode(this.quality);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RegisterInfo other = (RegisterInfo) obj;
        if (this.instanceId != other.instanceId) {
            return false;
        }
        if (!Objects.equals(this.serviceName, other.serviceName)) {
            return false;
        }
        if (!Objects.equals(this.ip, other.ip)) {
            return false;
        }
        if (!Objects.equals(this.version, other.version)) {
            return false;
        }
        if (!Objects.equals(this.quality, other.quality)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "RegisterInfo{" + "serviceName=" + serviceName + ", instanceId=" + instanceId + ", IP=" + ip + ", version=" + version + ", quality=" + quality + '}';
    }    
    
}
