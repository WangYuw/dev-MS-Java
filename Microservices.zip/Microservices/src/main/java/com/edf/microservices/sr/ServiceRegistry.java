/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.sr;

import com.edf.microservices.config.Config;
import com.edf.microservices.database.ServiceDB;
import com.edf.microservices.entities.RegisterInfo;
import com.edf.microservices.entities.ServiceQualityResponse;
import com.edf.microservices.entities.ServiceRequest;
import com.edf.microservices.entities.ServiceResponse;
import com.edf.microservices.server.RegisterServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author i41278
 */
public class ServiceRegistry {
    //private HashMap<String, List<RegisterInfo>> serviceList;
    private RegisterServer server;
    private ServiceDB database;

    public ServiceRegistry() {
        //this.serviceList = new HashMap<>();
    }

    public ServiceRegistry(RegisterServer server, ServiceDB database) {
        //this.serviceList = new HashMap<>();
        this.server = server;
        this.database = database;
    }
    
    public void getServerConnection(int port){
        getDBConnection();
        server.startServerConnection(port);
    }
    
    public void closeServerConnection(){
        closeDBConnection();
        server.stopServerConnection();
    }
    
    public void getDBConnection(){
        database.startDBConnection();
    }
    
    public void closeDBConnection(){
        database.stopDBConnection();
    }
    
    public void register(RegisterInfo regServ){
        /*
        List<RegisterInfo> list = this.serviceList.get(regServ.getServiceName());
        if(list == null){
            list = new ArrayList<>();
        }
        //if ID exists?
        list.add(regServ);
        this.serviceList.put(regServ.getServiceName(), list);
        */
        database.registerToDB(regServ);
    }
    
    public void unregister(long id){
        database.unregisterToDB(id);
    }
    
    public ServiceResponse findService(ServiceRequest req){
        RegisterInfo service = database.findServiceMinLoad(req.getServiceName(), req.getVersion());
        ServiceResponse resp = new ServiceResponse();
        resp.setServiceName(service.getServiceName());
        resp.setInstanceId(service.getInstanceId());
        resp.setIp(service.getIP());
        resp.setVersion(service.getVersion());
        resp.setTtl(Config.DEFAULT_TTL);
        return resp;
    }
    
    public List<RegisterInfo> findServices(){
        return database.findAllServices();
    }
    
    public void updateQuality(ServiceQualityResponse resp) {
        
    }

    @Override
    public String toString() {
        return "ServiceRegistry{" + "server=" + server + ", database=" + database + '}';
    }
    
}
