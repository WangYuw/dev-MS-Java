/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.entities;

/**
 *
 * @author i41278
 */
public class ServiceQuality {
    private float load;

    public ServiceQuality() {
    }

    public ServiceQuality(float load) {
        this.load = load;
    }

    public float getLoad() {
        return load;
    }

    public void setLoad(float load) {
        this.load = load;
    }

    @Override
    public String toString() {
        return "ServiceQuality{" + "load=" + load + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Float.floatToIntBits(this.load);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ServiceQuality other = (ServiceQuality) obj;
        if (Float.floatToIntBits(this.load) != Float.floatToIntBits(other.load)) {
            return false;
        }
        return true;
    }
    
    
    
}
