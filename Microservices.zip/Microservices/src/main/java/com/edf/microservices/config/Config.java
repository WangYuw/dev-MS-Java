/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.config;

/**
 *
 * @author i41278
 */
public final class Config {

    public static final String DEFAULT_HOST = "127.0.0.1";
    public static final int DEFAULT_PORT = 8080;

    public static final String JDBC_DRIVER = "org.postgresql.Driver";
    public static final String DB_URL_BASE = "jdbc:postgresql://";
    public static final String DB_URL_HOST = "localhost";
    public static final String DB_URL_PORT = "5432";
    public static final String DB_NAME = "srdb";
    public static final String DB_URL = DB_URL_BASE+DB_URL_HOST+":"+DB_URL_PORT+"/";
    public static final String DB_USER = "postgres";
    public static final String DB_PASSWORD = "postgres";
    public static final String TABLE_NAME = "registry";
    
    public static final int DEFAULT_TTL = 10;
}
