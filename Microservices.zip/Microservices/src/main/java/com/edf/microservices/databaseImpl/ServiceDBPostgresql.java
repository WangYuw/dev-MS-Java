/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edf.microservices.databaseImpl;

import com.edf.microservices.config.Config;
import com.edf.microservices.database.ServiceDB;
import com.edf.microservices.entities.RegisterInfo;
import com.edf.microservices.entities.ServiceQuality;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author i41278
 */
public class ServiceDBPostgresql implements ServiceDB {

    private Connection connection;

    @Override
    public void startDBConnection() {
        try {
            Class.forName(Config.JDBC_DRIVER);
            this.connection = DriverManager.getConnection(Config.DB_URL + Config.DB_NAME, Config.DB_USER, Config.DB_PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void stopDBConnection() {
        try {
            if(connection != null){
                this.connection.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initRegisterDB() {
        try {
            Statement stmt = connection.createStatement();
            String sql = new String(Files.readAllBytes(Paths.get("../config/inti.sql")));
            stmt.executeUpdate(sql);
            stmt.close();
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void registerToDB(RegisterInfo service) {
        try {
            String sql = "INSERT INTO " + Config.TABLE_NAME
                    + "(type_name, instance_id, ip, version, load)"
                    + " VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setString(1, service.getServiceName());
            preparedStmt.setLong(2, service.getInstanceId());
            preparedStmt.setString(3, service.getIP());
            preparedStmt.setString(4, service.getVersion());
            preparedStmt.setFloat(5, service.getQuality().getLoad());
            preparedStmt.execute();

            preparedStmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void unregisterToDB(long id) {
        try {
            String sql = "DELETE FROM " + Config.TABLE_NAME
                    + " WHERE id = " + id;
            Statement stmt = connection.createStatement();
            stmt.executeUpdate(sql);
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<RegisterInfo> findAllServices() {
        List<RegisterInfo> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM " + Config.TABLE_NAME
                    + " ORDER BY type_name, instance_id";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                RegisterInfo service = new RegisterInfo();
                service.setServiceName(rs.getString("type_name"));
                service.setInstanceId(rs.getLong("instance_id"));
                service.setIP(rs.getString("ip"));
                service.setVersion(rs.getString("version"));
                service.setQuality(new ServiceQuality(rs.getFloat("load")));
                list.add(service);
            }
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public RegisterInfo findServiceById(long id) {
        RegisterInfo service = new RegisterInfo();
        try {
            String sql = "SELECT type_name, instance_id, ip, version, load"
                    + " FROM " + Config.TABLE_NAME
                    + " WHERE instance_id = " + id;
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            service.setServiceName(rs.getString("type_name"));
            service.setInstanceId(rs.getLong("instance_id"));
            service.setIP(rs.getString("ip"));
            service.setVersion(rs.getString("version"));
            service.setQuality(new ServiceQuality(rs.getFloat("load")));
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
        return service;
    }

    @Override
    public RegisterInfo findServiceMinLoad(String name, String version) {
        RegisterInfo service = new RegisterInfo();
        try {
            String sql = "SELECT type_name, instance_id, ip, version, load"
                    + " FROM " + Config.TABLE_NAME
                    + " WHERE type_name = " + name
                    + " AND version = " + version
                    + " AND load ="
                    + " (SELECT MIN(load)"
                    + " FROM " + Config.TABLE_NAME
                    + " GROUP BY type_name)";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            service.setServiceName(rs.getString("type_name"));
            service.setInstanceId(rs.getLong("instance_id"));
            service.setIP(rs.getString("ip"));
            service.setVersion(rs.getString("version"));
            service.setQuality(new ServiceQuality(rs.getFloat("load")));
            rs.close();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceDBPostgresql.class.getName()).log(Level.SEVERE, null, ex);
        }
        return service;
    }

}
